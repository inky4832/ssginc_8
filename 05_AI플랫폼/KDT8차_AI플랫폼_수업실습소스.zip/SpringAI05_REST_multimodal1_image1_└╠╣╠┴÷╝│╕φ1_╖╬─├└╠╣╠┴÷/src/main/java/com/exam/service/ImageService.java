package com.exam.service;


public interface ImageService {

	public String describeLocalImage1();
	public String describeLocalImage2();
	public String describeLocalImage3();
	
}
