package com.exam.service;


public interface AudioUploadService {

	public String describeUploadAudio(String prompt, String path);
	
}
