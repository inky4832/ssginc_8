package com.exam.service;


public interface ImageGenerateService {

	public String generateImage(String question);
	
}
