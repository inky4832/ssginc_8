package com.exam.service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.stereotype.Service;

import com.exam.dto.FeedbackDTO;
import com.exam.entity.Feedback;
import com.exam.enumtype.SentimentType;
import com.exam.repository.FeedbackRepository;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class FeedbackServiceImpl implements FeedbackService{

	FeedbackRepository feedbackRepositoy;
	ChatClient chatClient;

	public FeedbackServiceImpl(FeedbackRepository feedbackRepositoy, ChatClient.Builder builder) {
		this.feedbackRepositoy = feedbackRepositoy;
		this.chatClient = builder.build();
	}

	@Override
	public List<FeedbackDTO> findAll() {
		
		List<Feedback> feedbackList = feedbackRepositoy.findAll();
		
		List<FeedbackDTO> feedbackDTOList = feedbackList.stream()
														.map(feedback->FeedbackDTO.builder()
																	   .id(feedback.getId())	
																	   .content(feedback.getContent())
																	   .createdAt(feedback.getCreatedAt())
																	   .sentimentScore(feedback.getSentimentScore())
																	   .sentiment(feedback.getSentiment())
																       .build())
														.collect(Collectors.toList());
														
		return feedbackDTOList;
	}

	@Override
	@Transactional
	public FeedbackDTO analyzeFeedback(String content) {
		
		/*
		   Talend 에서 요청:
		   
		     headers:{
		     
		     	"Content-Type":"text/plain"
		     }
		
		     body:   기분이 우울해
		
		*/
		String message = """
				
				다음 텍스트의 감정을 분석해서 POSITIVE,NEUTRAL,NEGATIVE 이라는 단어 하나로만 응답해줘.
				그리고 -1에서 1 사이의 감정 점수를 제공해줘.
				-1은 가장 NEGATIVE하고
				 0은 NEUTRAL하고 
				 1은 가장 POSITIVE 한거야.
				 
				응답형식: 감정타입|점수 형식으로 응답해줘.
				
				분석할 문장: {x}
				
				""";
		
		
		PromptTemplate template = new PromptTemplate(message);
		Prompt prompt = template.create(Map.of("x", content));
		
		String response = chatClient.prompt(prompt)
						 .call().content();
		
		log.info("LOGGER: content:{}", content);
		log.info("LOGGER: response:{}", response);
		
		String [] parts = response.split("\\|");
		
		log.info("LOGGER: parts:{}", Arrays.toString(parts));
		
		Feedback feedback = Feedback.builder()
							.content(content)
							.sentimentScore(Double.parseDouble(parts[1].trim()))
							.sentiment(SentimentType.valueOf(parts[0].trim()))
				            .build();
		
		
		feedbackRepositoy.save(feedback);
		
		
		
		FeedbackDTO dto = FeedbackDTO.builder()
						 .content(feedback.getContent())
						 .sentimentScore(feedback.getSentimentScore())
						 .sentiment(feedback.getSentiment())
						 .build();
		
		
		return dto;
	}




}
