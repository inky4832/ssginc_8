
import './App.css';

import { useEffect, useRef, useState } from 'react';

import { fetchFeedbackList, fetchFeedbackSave } from './api/httpService.js';


function App() {

  const [feedback, setfeedback] = useState("");
  const [feedbackList, setFeedbackList] = useState([]);

  useEffect(() => {

    const fun = async () => {
      const data = await fetchFeedbackList();
      setFeedbackList(data);
    }

    fun();
  }, [feedback]);

  async function handleSubmit(e) {
    e.preventDefault();

    const response = await fetchFeedbackSave(feedback);

    setFeedbackList([...feedbackList, feedback]);
    setfeedback("")
  }



  return (
    <div>
      <h1>감정분석</h1>
      <form onSubmit={handleSubmit}>
        <textarea
          value={feedback}
          onChange={(e) => setfeedback(e.target.value)}
          placeholder="분석내용 입력하기"
          rows="4"></textarea>
        <button
          type="submit">
          분석하기
        </button>
      </form>
      <h2>분석 결과 목록</h2>
      <table border="1">
        <thead>
          <tr>
            <th>Feedback</th>
            <th>Score</th>
            <th>Sentiment</th>
          </tr>
        </thead>
        <tbody>
          {feedbackList.map((item) => (
            <tr key={item.id}>
              <td>{item.content}</td>
              <td>{item.sentimentScore}</td>
              <td>
                {item.sentiment}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
