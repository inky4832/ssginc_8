package com.exam.service;


public interface AudioGenerateService {

	public  byte [] generateAudio(String content);
	
}
