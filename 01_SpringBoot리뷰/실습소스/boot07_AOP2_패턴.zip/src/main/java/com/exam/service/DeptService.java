package com.exam.service;

import java.util.List;

public interface DeptService {

	//핵심기능 메서드
	public String sayEcho();
	public List<String> list();
	
	
}
