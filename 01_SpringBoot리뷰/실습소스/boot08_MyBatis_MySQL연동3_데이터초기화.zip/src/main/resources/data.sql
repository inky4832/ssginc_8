-- data.sql

insert into dept ( deptno, dname, loc ) values(1,'인사','서울');
insert into dept ( deptno, dname, loc ) values(2,'개발','부산');
insert into dept ( deptno, dname, loc ) values(3,'관리','서울');