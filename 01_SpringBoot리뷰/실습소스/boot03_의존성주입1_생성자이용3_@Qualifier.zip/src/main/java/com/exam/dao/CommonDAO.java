package com.exam.dao;

import java.util.List;

public interface CommonDAO {
	
	public List<String> list();
 
}
